//Definere vars som skal indeholde nogle tids værdier
let seconds = 0;
let minutes = 0;
let hours = 0;

//definere vars til at holde "timer" værdien
let displaySeconds = 0;
let displayMinutes = 0;
let displayHours = 0;

//definere var til at holde setInterval() function
let interval = null;

//definere var til at holde stopUr status
let status = "stopped";


//Stopur funktion (logik til at vurdere hvornår den næste værdi skal blive forhøjet, osv.)
function stopWatch(){
    
    seconds++;

    //Logik til at vurdere hvornår den næste værdig skal forhøjes
    if(seconds / 60 === 1){
        seconds = 0;
        minutes++;

        if(minutes / 60 === 1){
            minutes = 0;
            hours++;
        }


    }

    
    //hvis sekunder/minutter/timer kun er en enkelt værdi, tilføj et 0 til værdien
    if(seconds < 10){
        displaySeconds = "0" + seconds.toString();
    }

    else{
        displaySeconds = seconds;
    }

    if(minutes < 10){
        displayMinutes = "0" + minutes.toString();
    }
    else{
        displayMinutes = minutes;
    }

    if(hours < 10){
        displayHours = "0" + hours.toString();
    }
    else{
        displayHours = hours;
    }

    
    
    //Viser updaterede værdier til brugeren.
    document.getElementById("display").innerHTML = displayHours + ":" + displayMinutes + ":" + displaySeconds;



}



function startStop(){
    if(status === "stopped"){

        //start stopuret  (ved at kalde på setInterval() function)
        interval = window.setInterval(stopWatch, 1000);
        document.getElementById("startStop").innerHTML = "Stop";
        status = "started"
    }
    else{
        window.clearInterval(interval);
        document.getElementById("startStop").innerHTML = "Start";
        status = "stopped";
    }
}

//funktion der nulstiller stopuret
function nulstil(){
    window.clearInterval(interval);
    seconds = 0;
    minutes = 0;
    hours = 0;
    document.getElementById("display").innerHTML = "00:00:00";
    document.getElementById("startStop").innerHTML = "Start";
    status = "stopped";
    
}